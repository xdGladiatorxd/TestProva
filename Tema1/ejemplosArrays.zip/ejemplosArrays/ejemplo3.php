<!--Ejemplo de array asociativo sencillo con acceso a un elemento.-->


<?php
    $capitales = array("Italia" => "Roma","Francia" => "Paris", "Portugal" => "Lisboa");
    echo "La capital de Francia es ".$capitales["Francia"];
?>

