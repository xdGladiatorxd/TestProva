<!--Veamos esta segunda forma de inicializar arrays asociativos 
-->


<?php
$alturas["Aneto"] = 3404;
$alturas["Teide"] = 3718;
$alturas["Mulhacen"] = 3748;
echo "El Aneto mide {$alturas["Aneto"]} metros";
?>


