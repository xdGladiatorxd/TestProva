<?php
function pie(){
    return "
    </html>
    ";
}