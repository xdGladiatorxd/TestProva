<!DOCTYPE html>
<html lang="es">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Ejemplo 2</title> 
</head> 
<body> 
    <p> 
<?php
function negrita($cadena1){
    return "<b>".$cadena1."</b>";
}
echo negrita("Negrita");
?>
</p> 
</body> 
</html> 