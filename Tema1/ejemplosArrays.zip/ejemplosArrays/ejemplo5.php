<!--Ejemplo de array bidimensional de índice numérico .-->


<?php
$usuarios = array(
array("Nacho", "valencia"),
array("Jaime", "Madrid"),
array("Maria", "Barcelona")
);
?>