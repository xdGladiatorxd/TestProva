<!DOCTYPE html>
<html lang="es">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Ejemplo 2</title> 
</head> 
<body> 
    <p> 
<?php
$nombre="Juan";
$apellidos="Palomo Gracia";
$edad="23 años";
$domicilio="c/America 33";
$codigoPostal="34017";
$telefono="596209934";
$profesion="Programador";
echo "Nombre: $nombre<br>";
echo "Apellidos: $apellidos<br>";
echo "Edad: $edad<br>";
echo "Domicilio: $domicilio<br>";
echo "Codigo Postal: $codigoPostal<br>";
echo "Telefono: $telefono<br>";
echo "Profesion: $profesion<br>";
?>
</p> 
</body> 
</html> 